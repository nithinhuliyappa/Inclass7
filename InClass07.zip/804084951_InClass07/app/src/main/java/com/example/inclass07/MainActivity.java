package com.example.inclass07;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements FirstFragment.OnFragmentListener, AddExpenseFragment.PassDataToFirstFragment{

    ArrayList<ExpenseModel> expenseModels = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirstFragment first= new FirstFragment();
        Bundle b = new Bundle();
        b.putSerializable(FirstFragment.LIST_KEY,expenseModels);

        first.setArguments(b);



       getSupportFragmentManager().beginTransaction()
                .add(R.id.container, first, "FirstFragment")
                .commit();
        //FirstFragment first = (FirstFragment) getSupportFragmentManager().findFragmentByTag("FirstFragment");




    }

    @Override
    public void goAddExpense() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, new AddExpenseFragment(), "addExpenses")
                .addToBackStack(null)
                .commit();
    }


    @Override
    public void passData(String expenseName, String expenseCategory, double Amt, Date date) {
        ExpenseModel expenseModel = new ExpenseModel(expenseName,expenseCategory, Amt, date ) ;
        expenseModels.add(expenseModel);

        getSupportFragmentManager().beginTransaction().replace(R.id.container,new FirstFragment(),"first")
                .addToBackStack(null)
                .commit();
    }
}
