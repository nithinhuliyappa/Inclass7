package com.example.inclass07;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;


/*
        RecyclerViewAdapter
 */
public class ExpenseAdapter extends RecyclerView.Adapter<ExpenseAdapter.ViewHolder> {

    public static String TRACK_KEY = "TRACK";
    ArrayList<ExpenseModel> mData;

    public ExpenseAdapter(ArrayList<ExpenseModel> expenseList) {
        this.mData = expenseList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.recyclerview, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        ExpenseModel expenseModel = mData.get(i);

/*        viewHolder.trackName.setText("Track:"+movie.trackName);
        viewHolder.albumName.setText("Album:"+movie.albumName);

        viewHolder.artistName.setText("Artist:"+movie.artistName);
        viewHolder.date.setText("Date:"+new SimpleDateFormat("MM-dd-yyyy").format(movie.updatedTime));

        viewHolder.movie = movie;*/

        viewHolder.expenseName.setText(expenseModel.expenseName);
        viewHolder.expenseName.setText(String.valueOf(expenseModel.amount));

        viewHolder.expenseModel = expenseModel;
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }



    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView expenseName;
        TextView expenseAmount;
        ExpenseModel expenseModel;
      //  Movie movie;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
/*            trackName = itemView.findViewById(R.id.trackNameID);
            albumName = itemView.findViewById(R.id.albumNameID);
            artistName = itemView.findViewById(R.id.movieNameID);
            date = itemView.findViewById(R.id.releaseYearID);*/

            expenseName = itemView.findViewById(R.id.expenseNameTextView);
            expenseAmount = itemView.findViewById(R.id.expenseAmtTextView);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Context context = itemView.getContext();
                    Intent i=new Intent(Intent.ACTION_VIEW);
                 //   i.setData(Uri.parse(movie.trackShareUrl));
                    context.startActivity(i);
                }
            });

        }
    }
}

