package com.example.inclass07;
import java.io.Serializable;
import java.util.*;

public class ExpenseModel implements Serializable {
    String expenseName;
    String categoryName;
    double amount;
    Date date;

    public ExpenseModel(String expenseName, String categoryName, double amount, Date date) {
        this.expenseName = expenseName;
        this.categoryName = categoryName;
        this.amount = amount;
        this.date = date;
    }
}
