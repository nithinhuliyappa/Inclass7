package com.example.inclass07;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.icu.util.CurrencyAmount;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddExpenseFragment extends Fragment {

    String expenseName;
    String categoryName;
    double amount;
    Date date;
    PassDataToFirstFragment passDataToFirstFragment;


    public AddExpenseFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_expense, container, false);

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Spinner spinner = getActivity().findViewById(R.id.spinner);
        List<String> categories = new ArrayList<String>();
        categories.add("Groceries");
        categories.add("Invioce");
        categories.add("Transportation");
        categories.add("Shopping");
        categories.add("Rent");
        categories.add("Trips");
        categories.add("Utilities");
        categories.add("Other");

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
        getActivity().findViewById(R.id.addExpenseButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mlistener.goAddExpense();
                EditText editText = (EditText) getActivity().findViewById(R.id.expenseNameEditText);
                expenseName = editText.getText().toString();

                Log.d("demo", "Expense :"+expenseName);

                EditText editText2 = (EditText) getActivity().findViewById(R.id.expenseAmountEditText);
                amount = Double.parseDouble(editText2.getText().toString());
                Log.d("demo", "Expense Amount :"+amount);

                date = new Date();
                Log.d("demo", "Expense date :"+date);

               // ExpenseModel expenseModels = new ExpenseModel(expenseName,categoryName,amount,date);

               // passDataToFirstFragment.passData(expenseModels);

                passDataToFirstFragment.passData(expenseName,categoryName,amount,date);

            }
        });

    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try{
            passDataToFirstFragment = (PassDataToFirstFragment)context;
        } catch (ClassCastException e){
            throw new ClassCastException(getActivity().toString()+" Should Implement OnFragmentTextChange");
        }
    }


    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        categoryName = parent.getItemAtPosition(position).toString();
        Log.d("demo", "onItemSelected: "+ categoryName);
    }
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

    public interface PassDataToFirstFragment{
        public  void passData(String expenseName, String expenseCategory, double Amt, Date date);
    }

}
