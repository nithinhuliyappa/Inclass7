package com.example.inclass07;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class FirstFragment extends Fragment {

    public static String LIST_KEY= "LIST_TAG";

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    public FirstFragment() {
        // Required empty public constructor
    }

    OnFragmentListener mlistener;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().findViewById(R.id.firstFragmentAddButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mlistener.goAddExpense();

            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentListener) {
            mlistener = (OnFragmentListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_first, container, false);
        recyclerView = view.findViewById(R.id.recyclerView);

        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        // Log.d("demo",">>processing recycler layout");
        mAdapter = new ExpenseAdapter((ArrayList<ExpenseModel>) this.getArguments().getSerializable(LIST_KEY));
        recyclerView.setAdapter(mAdapter);
        recyclerView.setVisibility(View.VISIBLE);

        return view;
    }


    public void addRecyclerView(ArrayList<ExpenseModel> expenseModels) {
            mAdapter.notifyDataSetChanged();
    }

    public interface OnFragmentListener{
         void goAddExpense();
    }
}
